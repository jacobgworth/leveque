  <div class="w-nav nav-bar _2" data-collapse="medium" data-animation="default" data-duration="400" data-contain="1">
    <div class="w-container">
      <a class="w-nav-brand logo _2" href="index.php"><img src="images/New-Story-Logo.png" width="160">
      </a>
      <nav class="w-nav-menu nav-menu" role="navigation"><a class="w-nav-link nav-link _2" href="families-page.php">Meet a Family</a><a class="w-nav-link nav-link _2" href="how.php">How It Works</a>
        <div class="w-dropdown" data-delay="0">
          <div class="w-dropdown-toggle nav-link">
            <div>Celebrate Your Birthday!</div>
            <div class="w-icon-dropdown-toggle"></div>
          </div>
          <nav class="w-dropdown-list"><a class="w-dropdown-link dropdown-link" href="birthdays.php">New Story Birthdays</a><a class="w-dropdown-link dropdown-link" href="create-campaign.php">Start a Campaign</a>
          </nav>
        </div>
      </nav>
      <div class="w-nav-button menu-button">
        <div class="w-icon-nav-menu menu-icon"></div>
        <div class="menu-text">MENU</div>
      </div>
    </div>
  </div>
