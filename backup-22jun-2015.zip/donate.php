<?php 
		        						$title = "Donate - New Story";
		        						include('header.php');
		        					?></head>
<body>
  <header class="w-section">
    <?php 
		        						//include('nav.php');
		        					?><div class="w-section donate-section">
    <div class="donation-embed">
      <h1>General Donation</h1>
      <div class="w-embed w-script donation-widget-embed">
        <div id="mc5i8hvnv0lic"><a href="https://app.moonclerk.com/pay/5i8hvnv0lic">General Donation Form</a>
        </div>
        <script type="text/javascript">
          var mc5i8hvnv0lic;(function(d,t) {var s=d.createElement(t),opts={"checkoutToken":"5i8hvnv0lic","width":"100%"};s.src='https://d2l7e0y6ygya2s.cloudfront.net/assets/embed.js';s.onload=s.onreadystatechange = function() {var rs=this.readyState;if(rs) if(rs!='complete') if(rs!='loaded') return;try {mc5i8hvnv0lic=new MoonclerkEmbed(opts);mc5i8hvnv0lic.display();} catch(e){}};var scr=d.getElementsByTagName(t)[0];scr.parentNode.insertBefore(s,scr);})(document,'script');
        </script>
      </div>
    </div>
  </div>
  <?php 
		        						include('footer.php');
		        					?>
