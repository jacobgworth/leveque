<?php 
		        						$title = "Donations - Transparency Dashboard - New Story";
		        						include('header.php');
		        					?></head>
<body>
  <?php 
		        						//include('nav.php');
		        					?><div class="w-section" id="families">
    <div class="w-container content-section">
      <h1 class="transparency-h1">Donations</h1>
      <p class="paragraph-narrow donations">Since our launch on November 15th, 2014 we’ve raised&nbsp;<span class="transparency-highlight">$89,859.64</span>&nbsp;in donations from 520 donors from all around the world. Enough to fund 16 families! Want to <a class="link-inline" href="families-page.html">donate and support a family</a>?</p>
      <p class="paragraph-narrow smaller">(numbers updated monthly)</p>
    </div>
  </div>
  <?php 
		        						include('footer.php');
		        					?>
