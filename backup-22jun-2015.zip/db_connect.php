<?php

error_reporting(E_ERROR | E_WARNING | E_PARSE);
/*$username="mothe_rads";
$password="";
$database="newstory_db";
$host="localhost";
*/
$username="avanttec_storyp";
$password="+g.iyX)zoxAF";
$database="avanttec_newstoryap";
$host="localhost";


mysql_connect($host,$username,$password);
@mysql_select_db($database) or die( "Unable to select database");
?>
