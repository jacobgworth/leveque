<?php 
session_start();
		    $title = "Create Campaign - New Story";
		      include('header2.php');
?></head>
<body>
  <?php 
		        						//include('nav.php');
		        					?>
            <div class="w-icon-dropdown-toggle"></div>
          </div>
          <nav class="w-dropdown-list"><a class="w-dropdown-link dropdown-link" href="birthdays.html">New Story Birthdays</a><a class="w-dropdown-link dropdown-link" href="create-campaign.html">Start a Campaign</a>
          </nav>
        </div>
      </nav>
      <div class="w-nav-button menu-button">
        <div class="w-icon-nav-menu menu-icon"></div>
        <div class="menu-text">MENU</div>
      </div>
    </div>
  </div>
  <div class="campaign-section hero">
    <div class="w-container content-section">
      <h1 class="white-h1">Run a <strong>race</strong>, give up your <strong>birthday</strong>, or get <strong>creative</strong> – give a <strong>new story</strong> to a family.</h1>
      <div class="campaign-cta-div"><a class="button hero campaign" href="#how-it-works">learn more</a>
        <div class="w-embed w-script button hero campaign">
			<a class="typeform-sharett link" style="color:white; text-decoration: none;" href="create-campaign.php" data-mode="1">START A CAMPAIGN</a>
			 
			
			
          <script>
            (function(){var qs,js,q,s,d=document,gi=d.getElementById,ce=d.createElement,gt=d.getElementsByTagName,id='typef_orm',b='https://s3-eu-west-1.amazonaws.com/share.typeform.com/';if(!gi.call(d,id)){js=ce.call(d,'script');js.id=id;js.src=b+'share.js';q=gt.call(d,'script')[0];q.parentNode.insertBefore(js,q)}})()
          </script>
        </div>
      </div>
    </div>
  </div>
  <div class="campaign-section" id="campaign-how-it-works">
    <div class="w-container content-section success-campaign" id="successful-campaigns">
      <h2 class="blue-h2">Anyone can help write a new story...</h2>
      <div class="w-row campaigners-row">
        <div class="w-col w-col-2 w-col-small-4 w-col-tiny-6"><img class="campaign-new-image" src="images/michael.png">
        </div>
        <div class="w-col w-col-2 w-col-small-4 w-col-tiny-6"><img class="campaign-new-image" src="images/Fwd__Reagan_s_Birthday_Campaign__-_matthew1818_gmail_com_-_Gmail.png">
        </div>
        <div class="w-col w-col-2 w-col-small-4 w-col-tiny-6"><img class="campaign-new-image" src="images/Screen Shot 2015-01-23 at 3.36.55 PM.png">
        </div>
        <div class="w-col w-col-2 w-col-small-4 w-col-tiny-6"><img class="campaign-new-image" src="images/Claudeane_Frank___LinkedIn.png">
        </div>
        <div class="w-col w-col-2 w-col-small-4 w-col-tiny-6"><img class="campaign-new-image" src="images/adding_Alexandria_to_team_page_-_matthew1818_gmail_com_-_Gmail.png">
        </div>
        <div class="w-col w-col-2 w-col-small-4 w-col-tiny-6"><img class="campaign-new-image" src="images/mike-profile-pic.png">
        </div>
      </div>
      <div class="w-row campaigners-row">
        <div class="w-col w-col-2 w-col-small-4 w-col-tiny-6"><img class="campaign-new-image" src="images/Claudia_Olah.png">
        </div>
        <div class="w-col w-col-2 w-col-small-4 w-col-tiny-6"><img class="campaign-new-image" src="images/Kristen_E__Gee.png">
        </div>
        <div class="w-col w-col-2 w-col-small-4 w-col-tiny-6"><img class="campaign-new-image" src="images/Fwd__Moody_s_Birthday_Campaign_-_matthew_newstorycharity_org_-_New_Story_Mail.png">
        </div>
        <div class="w-col w-col-2 w-col-small-4 w-col-tiny-6"><img class="campaign-new-image" src="images/me1.png">
        </div>
        <div class="w-col w-col-2 w-col-small-4 w-col-tiny-6"><img class="campaign-new-image" src="images/steves-pic.png">
        </div>
        <div class="w-col w-col-2 w-col-small-4 w-col-tiny-6"><img class="campaign-new-image" src="images/skelby-pic.png">
        </div>
      </div>
      <div class="w-row campaigners-row">
        <div class="w-col w-col-2 w-col-small-4 w-col-tiny-6"><img class="campaign-new-image" src="images/stephanie-pic.png">
        </div>
        <div class="w-col w-col-2 w-col-small-4 w-col-tiny-6"><img class="campaign-new-image" src="images/andrew-pic.png">
        </div>
        <div class="w-col w-col-2 w-col-small-4 w-col-tiny-6"><img class="campaign-new-image" src="images/Alan_Heck_-_Profile_Pictures___Facebook.png">
        </div>
        <div class="w-col w-col-2 w-col-small-4 w-col-tiny-6"><img class="campaign-new-image" src="images/Bobbi_Bravar_Hagler1.png">
        </div>
        <div class="w-col w-col-2 w-col-small-4 w-col-tiny-6"><img class="campaign-new-image" src="images/_3__Brett_Hagler.png">
        </div>
        <div class="w-col w-col-2 w-col-small-4 w-col-tiny-6"><img class="campaign-new-image" src="images/Linda_Kirchner_-_Profile_Pictures.png">
        </div>
      </div>
    </div>
    <div class="w-container content-section how-it-works" id="how-it-works">
      <h2 class="blue-h2">How It Works</h2>
      <div class="w-row campaign-row-how-it-works full">
        <div class="w-col w-col-4"><img src="images/1415151108_like-128.png" width="64">
          <h3 class="h3-light">Start a Campaign</h3>
          <p class="small-paragraph">Ask friends and family for donations instead of holiday gifts, run a 5k, or give up your birthday.</p>
        </div>
        <div class="w-col w-col-4"><img src="images/1415151111_heart-128.png" width="64">
          <h3 class="h3-light">Raise Funds</h3>
          <p class="small-paragraph">Once your campaign has ended your campaign will be assigned to a family and the money sent to the field.</p>
        </div>
        <div class="w-col w-col-4"><img src="images/1415151140_camera-128.png" width="64">
          <h3 class="h3-light">See the Impact</h3>
          <p class="small-paragraph">You and your supporters will be able to see exactly what you built and the lives you changed.&nbsp;</p>
        </div>
      </div><a class="button hero top" href="campaign-page.html">view a sample campaign</a>
      <div class="w-embed w-script button hero"><a class="typeform-share link" style="color:white; text-decoration: none;" href="create-campaign.php" data-mode="1" target="_blank">START A CAMPAIGN</a>
        <script>
          (function(){var qs,js,q,s,d=document,gi=d.getElementById,ce=d.createElement,gt=d.getElementsByTagName,id='typef_orm',b='https://s3-eu-west-1.amazonaws.com/share.typeform.com/';if(!gi.call(d,id)){js=ce.call(d,'script');js.id=id;js.src=b+'share.js';q=gt.call(d,'script')[0];q.parentNode.insertBefore(js,q)}})()
        </script>
      </div>
    </div>
    <div class="w-container content-section">
      <div>
        <h1 class="campaign-faqs">Campaign FAQs</h1>
      </div>
      <div class="w-row">
        <div class="w-col w-col-6">
          <p class="small-paragraph campaign"><span style="font-size: 19px;"><strong>What if I don’t raise my goal amount?<br></strong></span>No worries! We’ll help you along the way. At the end of your campaign we’ll combine your campaign with others to reach the $6,000 needed to build a new home!</p>
        </div>
        <div class="w-col w-col-6">
          <p class="small-paragraph campaign"><strong class="bold-faq">How do I know which family I help?<br></strong>After your campaign ends we match you and your supporters to a family in need and then when the new home is build each donor will receive a video of the family in their new home.</p>
        </div>
      </div>
    </div>
  </div>
  <div class="overlay-campaign-messages" data-ix="close-campaign-message-overlay">
    <div>
      <h1>Sample Campaign Messages</h1>
    </div>
    <div class="w-row">
      <div class="w-col w-col-6">
        <p class="white-paragraph">For this holiday season, we have the power to create a life-changing story for a family in desperate need. With your help, we can create extraordinary change for a family in Haiti experiencing life-threatening homelessness. Let's change their story!&nbsp;</p>
      </div>
      <div class="w-col w-col-6">
        <p class="white-paragraph">We have the opportunity to play hero in the lives of families experiencing life-threatening homelessness. I'm asking friends and family who are passionate about making a difference to join me. Together, let's write a new story!&nbsp;</p>
      </div>
    </div>
    <div class="close-overlay" data-ix="close-campaign-message-overlay">X</div>
  </div>
  <?php 
		        						include('footer.php');
		        					?>
