<?php
session_start();
$logged_user_id = $_SESSION['logged_user_id'];  
?>
<!DOCTYPE html>
<!-- This site was created in Webflow. http://www.webflow.com-->
<!-- Last Published: Thu Apr 30 2015 04:23:34 GMT+0000 (UTC) -->
<html data-wf-site="54ed2fd5e9be50bb55cab7e0" data-wf-page="550b82e4afd603c85d5dc62e">
<head>
  <meta charset="utf-8">
  <title>Current Campaign</title>
  <meta name="description" content="New Story is a different type of charity connecting donors with homeless families to create life-changing stories.">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="generator" content="Webflow">
  <link rel="stylesheet" type="text/css" href="css/normalize.css">
  <link rel="stylesheet" type="text/css" href="css/webflow.css">
  <link rel="stylesheet" type="text/css" href="css/newstoryapp.webflow.css">
  <link href='http://fonts.googleapis.com/css?family=Lato:300,400' rel='stylesheet' type='text/css'>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/webfont/1.4.7/webfont.js"></script>
  <script>
    WebFont.load({
      google: {
        families: ["Open Sans:300,300italic,400,400italic,600,600italic,700,700italic,800,800italic","Merriweather:300,400,700,900","Varela Round:400","Lato:100,100italic,300,300italic,400,400italic,700,700italic,900,900italic"]
      }
    });
  </script>
  <script type="text/javascript" src="https://use.typekit.net/sit1pgy.js"></script>
  <script type="text/javascript">
    try{Typekit.load();}catch(e){}
  </script>
    <meta property="og:image" content="https://daks2k3a4ib2z.cloudfront.net/54467223a05709a755daab06/54943e336840693f14fcc210_New-Story-100-percent-200.png" />
  <script src="https://cdn.optimizely.com/js/2383440548.js"></script>
  <script type="text/javascript">
    window.heap=window.heap||[],heap.load=function(t,e){window.heap.appid=t,window.heap.config=e;var a=document.createElement("script");a.type="text/javascript",a.async=!0,a.src=("https:"===document.location.protocol?"https:":"http:")+"//cdn.heapanalytics.com/js/heap.js";var n=document.getElementsByTagName("script")[0];n.parentNode.insertBefore(a,n);for(var o=function(t){return function(){heap.push([t].concat(Array.prototype.slice.call(arguments,0)))}},p=["clearEventProperties","identify","setEventProperties","track","unsetEventProperty"],c=0;c<p.length;c++)heap[p[c]]=o(p[c])};
      heap.load("1226628951");
  </script>
  <!-- Hotjar Tracking Code for newstorycharity.org -->
  <script>
    (function(f,b){
        var c;
        f.hj=f.hj||function(){(f.hj.q=f.hj.q||[]).push(arguments)};
        f._hjSettings={hjid:26279, hjsv:3};
        c=b.createElement("script");c.async=1;
        c.src="https://static.hotjar.com/c/hotjar-26279.js?sv=3";
        b.getElementsByTagName("head")[0].appendChild(c); 
    })(window,document);
  </script>
<script type="text/javascript" src="js/common.js"></script>
  <script type="text/javascript" src="js/modernizr.js"></script>
  <link rel="shortcut icon" type="image/x-icon" href="images/favicon (12).ico">
  <link rel="apple-touch-icon" href="https://daks2k3a4ib2z.cloudfront.net/img/webclip.png">
  <script type="text/javascript">var switchTo5x=true;</script>
<script type="text/javascript" src="http://w.sharethis.com/button/buttons.js"></script>
<script type="text/javascript">stLight.options({publisher: "5ff8b170-0f2e-40a4-ba89-3bc24c8b485f", doNotHash: false, doNotCopy: false, hashAddressBar: false});</script>
</head>
<body <?php if(!isset($_SESSION['logged_user_id'])) {echo 'class="not-logged"';} ?>>
  <div id="headerWrapper" data-contain="1" data-duration="400" data-animation="default" data-collapse="medium" class="w-nav nav-bar _2">
    <div class="w-container">
      <a href="index.php" class="w-nav-brand logo _2"><img width="160" alt="5463769cd17b82d661b42223_New-Story-Logo.png" src="images/New-Story-Logo.png">
      </a>

<nav role="navigation" class="w-nav-menu nav-menu">

<?php
 if(isset($_SESSION['get_started'])) {
?>
<a target="_blank" href="http://newstorycharity.org/campaign-tips" class="w-nav-link nav-link _2" style="max-width: 940px;">Get Started</a>
<?php unset($_SESSION['get_started']); } ?>

<?php if(isset($_SESSION['logged_user_id'])) { ?>

              
              
         <div class="w-dropdown" data-delay="0">
          <?php
           include 'db_connect.php';
           $email_login;
           $logged_user_id;
           $getquery="SELECT * FROM `users` where `user_id` = '$logged_user_id';";
    
        $qury = mysql_query($getquery);
    
        while($rows=mysql_fetch_array($qury))
        
           { 
			
			?>
			
          <div class="w-dropdown-toggle w-clearfix navlink dropdown"><img class="navbar-account-image" src="<?php $_SERVER['DOCUMENT_ROOT'];?>/newstoryapp/uploads/<?php echo $rows['imageurl'];?>" alt="">
            <div class="navbar-account-name"><?php echo $rows['name'];?></div>
            <div class="w-icon-dropdown-toggle"></div>
          </div>
          
          
          <?php
          }
          ?>
          <nav class="w-dropdown-list">
			   <a class="w-dropdown-link navbar-dropdown-link" href="editUser.php">Edit Profile</a>
			  <a class="w-dropdown-link navbar-dropdown-link" href="dashboard.php">Dashboard</a>
          <!--<a class="w-dropdown-link navbar-dropdown-link" href="press-inquiries.php">Any feedback?</a>-->
          <a class="w-dropdown-link navbar-dropdown-link" href="http://newstorycharity.org/campaign-tips">Campaign Tips</a>
		  <a class="w-dropdown-link navbar-dropdown-link" href="faqs.php">Help Docs/FAQ</a><a class="w-dropdown-link navbar-dropdown-link" href="logout.php">Log Out</a>
          </nav>
        </div>
      </nav>
<?php } ?>

               
      

      <div class="w-nav-button menu-button">
        <div class="w-icon-nav-menu menu-icon"></div>
        <div class="menu-text">MENU</div>
      </div>
    </div>
  </div>
